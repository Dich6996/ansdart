
        var $city = $('.user-city');
        var city = '';
        $.get('https://api.sypexgeo.net/json/', function (location) {
            city = location.city.name_en;
            console.log(location.city.name_en);
            $('.user-city').text(city);
        })
